#!/bin/bash
#cd $(dirname $0)
cd "`dirname -- "$0"`"

u=`uname -m`
if test "$u" == "x86_64"
	then
#		sudo $PWD/node_modules/forever/bin/forever64 stop file.js &> forever.txt
		sudo pkill -9 node64
	else
#		sudo $PWD/node_modules/forever/bin/forever32 stop file.js &> forever.txt
		sudo pkill -9 node32
fi
echo "Ubiq stopped successfully!"
echo Ubiq is stopped >status.txt
