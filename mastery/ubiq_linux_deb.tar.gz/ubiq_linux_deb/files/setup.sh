sudo chmod 777 files/temp.txt
sudo chmod 777 files/sk.json

#echo "Enter EMAIL used for signup at Ubiq(q to quit):"
#while read uname;do
#        if [ -z "$uname" ];then
#                echo "Enter EMAIL used for signup at Ubiq(q to quit):"
#        elif [ "$uname" = "q" ];then
#		exit 1
#	else
#                break
#        fi
#done
#echo "PASSWORD used for signup(q to quit):"
#while read passwd;do
#        if [ -z "$passwd" ];then
#                echo "PASSWORD used for signup(q to quit):"
#        elif [ "$passwd" = "q" ];then
#                exit 1
#        else
#                break
#        fi
#done

#sudo curl -s -o files/temp.txt -d "username=$uname" -d "password=$passwd" "https://ubiq.co/settings/test/"
status=$?
if [ $status = 7 ];then
	echo Unable to connect to Ubiq. Please connect to internet and try again.
	exit 1
elif [ $status = 0 ];then
	op=$(head -n 1 files/temp.txt)
#	if [ "$op" == "false" ];then
#		echo Please enter correct email and password
#	else
#		echo $op > files/secret_key.json
		echo { >./files/data.json
		echo } >> ./files/data.json
		> ./files/db_list.txt
		echo 0 > ./files/setup.txt
		c=$(<files/db_list.txt grep -c '[^[:space:]]')
		while [ $c -eq 0 ]; do
			./files/db.sh
			 c=$(<files/db_list.txt grep -c '[^[:space:]]')
			if [ $c -eq 0 ];then
				echo				
				echo ADD AT LEAST 1 DATABASE
				echo
			fi
		done	
		./files/start.sh
		echo Setup complete. If you are setting ubiq for the first time, then go back to your browser
		echo and click Next button to test the setup.
#	fi
fi


