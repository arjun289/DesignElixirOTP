var conn_det=require('./data.json'),
	express = require('express'),
	pg = require('pg'),
	//crypto = require('crypto'),
	fs = require('fs');
	var types = require('pg').types;
types.setTypeParser(1082, String);
types.setTypeParser(1114, String);
types.setTypeParser(1184, String);
var app = express(),
	mysql = require('mysql'),
	secret_key=require('./sk.json')['secret_key'];	
	var native_client={"11":"SQL Server Native Client 11.0","10":"SQL Server Native Client 10.0"}
 app.use(express.bodyParser());
 
process.setMaxListeners(0);
app.setMaxListeners(0);
var mssql="";
/*
if(process.platform=="win32" || process.platform=="win64"){ 
	var mssql = require('msnodesql');
}
else{
	var mssql = "";
}
*/

process.on('uncaughtException', function (err) {
  fs.writeFileSync('log.txt',err);
});

 
if(process.argv[2]=="start"){
	try{
		fs.writeFileSync('pid.txt',process.pid);
		fs.writeFileSync('log.txt','Listening on port 39393');
		app.listen(39393);
		}
	catch(err){
		fs.writeFileSync('log.txt',err.message);
		return;
	}		
}
else if(process.argv[2]=="stop"){
	try{
		fs.appendFile('log.txt', '\r\nStopping Server', function (err) {
			fs.writeFileSync('log.txt',err.message);
			return;
		});
		process.kill(fs.readFileSync('pid.txt').toString());
		}
	catch(err){
		fs.writeFileSync('log.txt',err.message);
		return;
	}		
} 

function get_connection(db){
	var data={},conn;
	data['status']=false;
	data['conn']='';
	try{
		switch(conn_det[db]['type'].toLowerCase()){
			case 'mysql':
				if(conn_det[db]['port']!=""){
					conn = mysql.createConnection({
					  host     : conn_det[db]['host'],
					  port     : conn_det[db]['port'],					  
					  user     : conn_det[db]['user'],
					  password : conn_det[db]['password'],
					  database : db,
					  insecureAuth : true,
					  dateStrings:true,					  
					  timezone:'Z'
					});
				}
				else{
					conn = mysql.createConnection({
					  host     : conn_det[db]['host'],
					  user     : conn_det[db]['user'],
					  password : conn_det[db]['password'],
					  database : db,
					  insecureAuth : true,
					  dateStrings:true,							  
					  timezone:'Z'
					});
				}
			break;
			case 'postgresql':
				/*if(conn_det[db]['port']=="" || conn_det[db]['port']=="5432"){
					var conString = "postgres://"+conn_det[db]['user']+":"+conn_det[db]['password']+"@"+conn_det[db]['host']+"/"+db;
				}else{
					var conString = "postgres://"+conn_det[db]['user']+":"+conn_det[db]['password']+"@"+conn_det[db]['host']+":"+conn_det[db]['port']+"/"+db;
				}*/
				if(conn_det[db]['port']=="" || conn_det[db]['port']=="5432"){
						var conString = {
							 host     : conn_det[db]['host'],
							  user: conn_det[db]['user'], 
							  database: db, 
							  password: conn_det[db]['password'],
							  port: 5432, 
							  max: 3, 
							  idleTimeoutMillis: 30000, // how long a client is allowed to remain idle before being closed
							};
						//var conString = "postgres://"+db['d_user_name']+":"+db['d_pd']+"@"+db['d_host_name']+"/"+db1;
					}else{
						var conString = {
							 host     : conn_det[db]['host'],
							  user: conn_det[db]['user'], 
							  database: db, 
							  password: conn_det[db]['password'],
							  port: conn_det[db]['port'], 
							  max: 3, 
							  idleTimeoutMillis: 30000, // how long a client is allowed to remain idle before being closed
							};
						//var conString = "postgres://"+db['d_user_name']+":"+db['d_pd']+"@"+db['d_host_name']+":"+db['d_port']+"/"+db1;
					}
				conn = new pg.Client(conString);

			break;			
			case 'mssql':
			break;
			default:
				return data;
			break;
		}
		data['conn']= conn;
		data['status']=true;
		return data;
		}
	catch(err){
		fs.writeFileSync('log.txt',err.message);
		return data;
		}
}


app.options('*', function(req, res) {
	res.header('Access-Control-Allow-Origin', '*');
	res.header('Access-Control-Allow-Credentials', true); 
	res.header('Access-Control-Allow-Methods', 'POST,OPTIONS,GET');
	res.header('Access-Control-Allow-Headers', 'Content-Type');  
});

app.get('/test_connection',function(request,response){
	response.header("Access-Control-Allow-Origin", "*");
	response.header('Access-Control-Allow-Methods: GET');
	response.header('Content-Type', 'application/json');
	response.send(true);
});



app.post('/get_data', function(request, response){
	response.header("Access-Control-Allow-Origin", "*");
	response.header('Access-Control-Allow-Methods: POST');
	response.header('Content-Type', 'application/json');
	response.setTimeout(0);
	try{
	var hmsg="";//crypto.createHmac("SHA256", secret_key).update(request.body.msg).digest('hex');
	if(true)	{
	var conn_data=get_connection(request.body.database),
		query_string=request.body.query,
		data={},
		keyword=query_string.match(/insert |update |delete |create |drop |grant |alter |lock |index |trigger |;/gi);
		if(conn_data['status']==true){
			switch(conn_det[request.body.database]['type'].toLowerCase()){
				case 'mysql':
					//var query_string=request.body.query,data={};
					//var keyword=query_string.match(/insert |update |delete |create |drop |grant |alter |lock |index |trigger |union |sleep |;/gi);
					if(keyword==null){					
						conn_data['conn'].query(query_string, function(err, rows, fields) {
						if (err) {		
							fs.writeFileSync('log.txt',err.message);
							data['status']=false;
							data['message']=err.message;
							conn_data['conn'].end();								
							response.send(data);
							conn_data=null;
							data=null;
							return;
							}
							//convert blob to string
							var pos=-1;
							for(j in rows[0]){
								if( Buffer.isBuffer(rows[0][j]) || rows[0][j] instanceof Object ){
									pos=j;
									}
								}
							if(pos != -1){
								for(i in rows){
										rows[i][pos]=rows[i][pos].toString('utf8');
									}
							}
							data['rows']=rows;
							data['headers']=fields;
							data['status']=true;
							conn_data['conn'].end();
							response.send(data);
							conn_data=null;							
							data=null;
							return;
						});
					}
					else{
						data['status']=false;
						data['message']="semicolon and keywords like insert|update|delete|create|drop|grant|alter|lock|index|trigger|union|sleep are not allowed in query";
						conn_data['conn'].end();
						response.send(data);
						data=null;
						conn_data=null;
						return;
					}
				break;
				case 'postgresql':
					if(keyword==null){					
					conn_data['conn'].connect(function(err) {
							conn_data['conn'].query(query_string, function(err, result) {
							if (err) {		
								fs.writeFileSync('log.txt',err.message);
								data['status']=false;
								data['message']=err.message;
								conn_data['conn'].end();									
								response.send(data);
								conn_data=null;
								data=null;
								return;
								}
								data['rows']=result.rows;
								data['headers']=result.fields;
								data['status']=true;
								conn_data['conn'].end();
								response.send(data);
								conn_data=null;							
								data=null;
								return;
							});
						});
					}
					else{
						data['status']=false;
						data['message']="semicolon and keywords like insert|update|delete|create|drop|grant|alter|lock|index|trigger|union|sleep are not allowed in query";
						conn_data['conn'].end();
						response.send(data);
						data=null;
						conn_data=null;
						return;
					}				
				
				break;				
				case 'mssql':
				/*
					//var query_string=request.body.query,data={};
					//var keyword=query_string.match(/insert |update |delete |create |drop |grant |alter |lock |index |trigger |union |sleep |;/gi);
					if(keyword==null){					
						var db=request.body.database;
						if(conn_det[temp]['user']=="" || typeof conn_det[temp]['user'] == "undefined"){
								if(conn_det[db]['port']==""){
									var sql_conn_str="Driver={"+native_client[conn_det[db]['native_client']]+"};Server="+conn_det[db]['host']+";Database="+db+";Trusted_Connection={Yes}";
									}
									else{
									var sql_conn_str="Driver={"+native_client[conn_det[db]['native_client']]+"};Server={"+conn_det[db]['host']+","+conn_det[db]['port']+"};Database="+db+";Trusted_Connection={Yes}";
								}
								var sql_conn_str="Driver={"+native_client[conn_det[temp]['native_client']]+"};Server="+conn_det[temp]['host']+";Database="+temp+";Trusted_Connection={Yes}";
							}
							else{
								if(conn_det[db]['port']==""){
									var sql_conn_str="Driver={"+native_client[conn_det[db]['native_client']]+"};Server="+conn_det[db]['host']+";Database="+db+";Trusted_Connection={Yes};UID="+conn_det[db]['user']+";PWD="+conn_det[db]['password'];
									}
									else{
									var sql_conn_str="Driver={"+native_client[conn_det[db]['native_client']]+"};Server={"+conn_det[db]['host']+","+conn_det[db]['port']+"};Database="+db+";Trusted_Connection={Yes};UID="+conn_det[db]['user']+";PWD="+conn_det[db]['password'];
								}
							}
						mssql.query(sql_conn_str,query_string, function (err, results) {
						if (err) {		
							data['status']=false;
							data['message']=err.message.replace(err.message.substr(err.message.indexOf('['),err.message.lastIndexOf(']')+1),"");
							response.send(data);
							data=null;
							return;
							}
							data['rows']=results;
							var fields=[];
							for(key in results[0]){
								fields.push({'name':key});
							}							
							data['headers']=fields;
							data['status']=true;	
							response.send(data);
							data=null;
							fields=null;
							return;
						});
					}
					else{
						data['status']=false;
						data['message']="semicolon and keywords like insert|update|delete|create|drop|grant|alter|lock|index|trigger|union|sleep are not allowed in query";
						response.send(data);
						data=null;
						return;
					}
					*/
				break;
				default:
					//var data={};
					//conn_data['conn'].end();
					data['status']=false;
					data['message']="Unable to connect to data source. Check database details in data.json file. Also check if your database server is running."
					response.send(data);	
					data=null;
					return;
				break;
			}
			return;
		}
		else{
			data['status']=false;
			data['message']="Unable to connect to data source. Check database config details."
			response.send(data);
			data=null;
			return;
		}
	}
	else{
		var data={};
		data['status']=false;
		data['message']="Unable to authenticate. Please update the secret key & restart server"
		response.send(data);
		data=null;
		return;
	}
	}
	catch(err){
		fs.writeFileSync('log.txt',err.message);
		var data={};
		data['status']=false;
		data['message']="Unable to get data. Please try again.";
		//if(conn_data['status']==true && conn_det[request.body.database]['type'].toLowerCase()=="mysql"){conn_data['conn'].end()}
		response.send(data);
		//conn_data=null;
		data=null;
		return;
	}	
});


app.post('/get_fields', function(request, response){
	response.header("Access-Control-Allow-Origin", "*");
	response.header('Access-Control-Allow-Methods: POST');
	response.header('Content-Type', 'application/json');
try{
	var hmsg="",count=0;
	for(key in conn_det){count++};
	}
	catch(error){
	fs.writeFileSync('log.txt',error.message);
		return;
	}
	
function isEmptyObject(obj) {
  return !Object.keys(obj).length;
}

if(true)	{
	if(!isEmptyObject(conn_det)){
	var data={},conn_data={};
		for(var key in conn_det){
			try{
				conn_data[key]=get_connection(key);
				
				data[key]={};	
				if(conn_data[key]['status']==true){		
					data[key]['type']=conn_det[key]['type'];
					switch(conn_det[key]['type'].toLowerCase()){
						case 'mysql':
							var query='select table_name,column_name,data_type from information_schema.columns where table_schema=\''+key+'\'';
							
							//scope defined to capture value of key in each iteration
							(function(temp) {
								conn_data[temp]['conn'].query(query,function(err, rows, fields) {
									if (err) {
										fs.writeFileSync('log.txt',err.message);
										data[temp]['status']=false;
										conn_data[temp]['conn'].end();										
									}
									else{
									
										data[temp]['rows']=rows;
										data[temp]['fields']=fields;
										data[temp]['status']=true;
										conn_data[temp]['conn'].end();
									}
									--count;
									if(count<=0){conn_data=null;response.send(data);data=null;conn_data=null;return;}
								});
							})(key);
						break;
						case 'postgresql':
							//scope defined to capture value of key in each iteration
							(function(temp) {
							conn_data[temp]['conn'].connect(function(err) {
							query='select table_schema||\'.\'||table_name,column_name,data_type from information_schema.columns where table_schema not in (\'information_schema\',\'pg_catalog\') and table_schema not like \'pg_toast%\' and table_catalog=\''+temp+'\' order  by table_name,column_name';
								conn_data[temp]['conn'].query(query,function(err, result) {
									if (err) {
										fs.writeFileSync('log.txt',err.message);
										data[temp]['status']=false;
										conn_data[temp]['conn'].end();										
									}
									else{
										data[temp]['rows']=result.rows;
										data[temp]['fields']=result.fields;
										data[temp]['status']=true;
										conn_data[temp]['conn'].end();
									}
									--count;
									if(count<=0){conn_data=null;response.send(data);data=null;conn_data=null;return;}
								});
							});
								
								
							})(key);
						
						break;						
						case 'mssql':
						/*
							var query='select table_name,column_name,data_type from '+key+'.information_schema.columns';
							//scope defined to capture value of key in each iteration						
							(function(temp) {
							if(conn_det[temp]['user']=="" || typeof conn_det[temp]['user'] == "undefined"){
								if(conn_det[db]['port']==""){
									var sql_conn_str="Driver={"+native_client[conn_det[db]['native_client']]+"};Server="+conn_det[db]['host']+";Database="+db+";Trusted_Connection={Yes}";
									}
									else{
									var sql_conn_str="Driver={"+native_client[conn_det[db]['native_client']]+"};Server={"+conn_det[db]['host']+","+conn_det[db]['port']+"};Database="+db+";Trusted_Connection={Yes}";
								}
								var sql_conn_str="Driver={"+native_client[conn_det[temp]['native_client']]+"};Server="+conn_det[temp]['host']+";Database="+temp+";Trusted_Connection={Yes}";
							}
							else{
								if(conn_det[db]['port']==""){
									var sql_conn_str="Driver={"+native_client[conn_det[db]['native_client']]+"};Server="+conn_det[db]['host']+";Database="+db+";Trusted_Connection={Yes};UID="+conn_det[db]['user']+";PWD="+conn_det[db]['password'];
									}
									else{
									var sql_conn_str="Driver={"+native_client[conn_det[db]['native_client']]+"};Server={"+conn_det[db]['host']+","+conn_det[db]['port']+"};Database="+db+";Trusted_Connection={Yes};UID="+conn_det[db]['user']+";PWD="+conn_det[db]['password'];
								}
							}
							mssql.query(sql_conn_str,query, function (err, results) {
									if (err) {
										data[temp]['status']=false;
									}
									else{
										data[temp]['rows']=results;
										var fields=[];
										for(key in results[0]){
											fields.push({'name':key});
										data[temp]['fields']=fields;
										data[temp]['status']=true;	
										}
									}
									--count;
									if(count<=0){conn_data=null;response.send(data);data=null;conn_data=null;return;}
								});
							})(key);
							*/
						break;
						default:
							(function(temp) {
								data[temp]['status']=false;
								--count;
								conn_data[temp]['conn'].end();
								if(count<=0){conn_data=null;response.send(data);data=null;conn_data=null;return;}
							})(key);
						break;
					}
				}
				else{
					(function(temp) {
						data[temp]['status']=false;
						--count;
						if(count<=0){conn_data=null;response.send(data);data=null;conn_data=null;return;}
					})(key);
				}
			}
			catch(err){
			fs.writeFileSync('log.txt',err.message);
				(function(temp) {
						data[temp]['status']=false;
						--count;
						if(conn_data[key]['status']==true && conn_det[key]['type'].toLowerCase()=='mysql'){	conn_data[temp]['conn'].end();}
						if(count<=0){conn_data=null;response.send(data);data=null;conn_data=null;return;}
					})(key);
			}
		}
		return;
	}
	else{
		var data={};
		data['status']=false;
		data['message']="No database detected. Please add databases to your local ubiq agent"
		response.send(data);
		data=null;
		return;
	
	}
}
else{
	var data={};
	data['status']=false;
	data['message']="Unable to authenticate. Please update the secret key & restart server"
	response.send(data);
	data=null;
	return;
}
});


app.post('/test_db',function(request,response){
	response.header("Access-Control-Allow-Origin", "*");
	response.header('Access-Control-Allow-Methods: POST');
	response.header('Content-Type', 'application/json');
	
	var data=false,conn;
	try{
		switch(request.body.type.toLowerCase()){
			case 'mysql':
				if(request.body.port!=""){
					conn = mysql.createConnection({
					  host     : request.body.host,
					  port     : request.body.port,					  
					  user     : request.body.user,
					  password : request.body.password,
					  database : request.body.db,
					  insecureAuth : true,
					  timezone:'Z'
					});
				}
				else{
					conn = mysql.createConnection({
					  host     : request.body.host,
					  user     : request.body.user,
					  password : request.body.password,
					  database : request.body.db,
					  insecureAuth : true,
					  timezone:'Z'
					});
				}
				console.log(request.body.db+' '+request.body.host+' '+request.body.user+' '+request.body.port);
				conn.connect(function (err) {
						// connected! (unless `err` is set)
						if (err) {
							response.send(false);
							conn=null;
							data=null;
							return;
						} else {
							response.send(true);
							conn=null;
							data=null;
							return;
						}
				});
			break;
			case 'postgresql':				
				/*if(request.body.port=="" || request.body.port=="5432"){
					var conString = "postgres://"+request.body.user+":"+request.body.password+"@"+request.body.host+"/"+request.body.db;
				}else{
					var conString = "postgres://"+request.body.user+":"+request.body.password+"@"+request.body.host+":"+request.body.port+"/"+request.body.db;
				}*/
				if(request.body.port=="" || request.body.port=="5432"){
						var conString = {
							 host     : request.body.host,
							  user: request.body.user, 
							  database: request.body.db, 
							  password: request.body.password,
							  port: 5432, 
							  max: 3, 
							  idleTimeoutMillis: 30000, // how long a client is allowed to remain idle before being closed
							};
						//var conString = "postgres://"+db['d_user_name']+":"+db['d_pd']+"@"+db['d_host_name']+"/"+db1;
					}else{
						var conString = {
							 host     : request.body.host,
							  user: request.body.user, 
							  database: request.body.db, 
							  password: request.body.password,
							  port: request.body.port, 
							  max: 3, 
							  idleTimeoutMillis: 30000, // how long a client is allowed to remain idle before being closed
							};
						//var conString = "postgres://"+db['d_user_name']+":"+db['d_pd']+"@"+db['d_host_name']+":"+db['d_port']+"/"+db1;
					}
				//console.log(conString);
				conn = new pg.Client(conString);
				conn.connect(function (err) {
						// connected! (unless `err` is set)
						if (err) {
							response.send(false);
							conn=null;
							data=null;
							return;
						} else {
							response.send(true);
							conn=null;
							data=null;
							return;
						}
				});
			break;			
			}
		}
	catch(err){
		fs.writeFileSync('log.txt',err.message);
		conn=null;
		response.send(data);
		data=null;
		return;
		}
});

