#cd $(dirname $0)
cd "`dirname -- "$0"`"

echo
echo Loading. Please wait...
echo
sudo chmod 755 files/start.sh
sudo chmod 755 files/stop.sh
sudo chmod 755 files/setup.sh
sudo chmod 777 files/ubiq.sh
sudo chmod 777 files/setup.txt
sudo chmod 755 files/db.sh
sudo chmod 777 files/temp.txt
sudo chmod 777 files/sk.json
sudo chmod 777 files/data.json
sudo chmod 777 files/db_list.txt
sudo chmod 777 files/status.txt
sudo chmod 777 files/forever.txt
sudo chmod 777 files/log.txt
sudo chmod 777 files/pid.txt
sudo chmod 777 log.txt
sudo chmod 777 pid.txt

sudo chmod 755 files/node64
sudo chmod 755 files/node32
sudo chmod 755 "$PWD/files/node_modules/forever/bin/forever32"
sudo chmod 755 "$PWD/files/node_modules/forever/bin/forever64"
sudo chmod 755 "$PWD/files/node_modules/forever/bin/foreverd"
sudo chmod 755 "$PWD/files/node_modules/forever/bin/monitor"
sudo iptables -D INPUT -p tcp --dport 39393 -j ACCEPT 2>/dev/null
sudo iptables -I INPUT -p tcp --dport 39393 -j ACCEPT

#add autostart on boot
echo \#!/bin/bash >files/ubiq.sh
echo \"$PWD/files/start.sh\" >> files/ubiq.sh
sudo cp files/ubiq.sh /etc/init.d
sudo update-rc.d ubiq.sh defaults > /dev/null 2>&1
sudo chmod +x /etc/init.d/ubiq.sh

c=$(<files/db_list.txt grep -c '[^[:space:]]')
if [ $c -eq 0 ]; then
  echo 0 > files/setup.txt
  files/setup.sh
  echo 1 > files/setup.txt
	exit 1
fi


echo Select action for ubiq client:
echo -----------------------------
echo 1. Install / Reset client
echo 2. Start agent
echo 3. Stop agent
#echo 4. Check status of agent
echo 4. Add/Remove database connections in client
#echo 6. Uninstall agent
echo 5. Quit
#echo 8. Reset database connections

echo Select option\(1-5\):
read action

case "$action" in 
1)./files/setup.sh;;
2)./files/start.sh;;
3)./files/stop.sh;;
41)cat files/status.txt;;
4)./files/db.sh
echo Restarting local ubiq server with updated settings
./files/stop.sh
./files/start.sh
echo
	echo "NOTE: To access newly added db, log into ubiq, go to data source tab of your project,"
	echo "click Add Data Source and select db from drop down"	
echo

;;
6)echo There is no uninstall process. You just have to delete this folder;;
5)exit 1;;
8)echo Are you sure you want to reset - y/n?
	read option
	if [ "$option" = "y" ];then
		echo { >files/db.json
		echo } >> files/db.json
		> files/db_list.txt
		echo Database details reset. No databases added yet. You can add new connection details.
		echo Restarting local ubiq server with updated settings
		./files/stop.sh
		./files/start.sh
	fi
;;
*)echo Please enter option 1-5
 ;; 

esac
