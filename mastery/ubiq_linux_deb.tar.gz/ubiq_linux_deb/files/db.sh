#cd $(dirname $0)
cd "`dirname -- "$0"`"

sudo chmod 777 data.json
sudo chmod 777 db_list.txt
sudo chmod 777 temp_list.txt
sudo chmod 777 temp_db_detail.txt


u=`uname -m`
if test "$u" == "x86_64"
        then
                "sudo $PWD/node_modules/forever/bin/forever64" stop file.js &> forever.txt
                "sudo $PWD/node_modules/forever/bin/forever64" start file.js start &> forever.txt
           
else
                "sudo $PWD/node_modules/forever/bin/forever32" stop file.js &> forever.txt
                "sudo $PWD/node_modules/forever/bin/forever32" start file.js start &> forever.txt
                
fi



add_db(){
while true;do
echo "Enter database type(1 for MySQL,2 for PostgreSQL,q to quit):"
while read type;do
	if [ "$type" != "1" ] && [ "$type" != "2" ] && [ "$type" != "q" ];then
		echo "Enter database type(1 for MySQL,2 for PostgreSQL,q to quit):"
	elif [ "$type" = "q" ];then
		exit 1	
	else 
		break
	fi
done
if [ "$type" == "1" ];then
type="mysql"
fi
if [ "$type" == "2" ];then
type="postgresql"
fi

echo "Enter database details"
echo "----------------------"
echo "Name of database:"
while read name;do
	if [ -z "$name" ];then
		echo "Name of database:"
	else
		break
	fi
done

echo "Host(ip or localhost or url):"
while read host;do
        if [ -z "$host" ];then
                echo "Host(ip or localhost or url):"
        else
                break
        fi
done
echo "Port(leave blank for default):"
read port
if [ -z "$port" ] &&  [ "$type" == "mysql" ];then  
	port=3306
fi
if [ -z "$port" ] &&  [ "$type" == "postgresql" ];then
        port=5432
fi
#if [ "$type" = "2" ];then
#echo "Native client version(9 or 10 or 11):"
#while read client;do
#        if [ -z "$client" ];then
#                echo "Native client version(9 or 10 or 11):"
#        else
#                break
#        fi
#done
#fi
echo "Username of database user:"
while read uname;do
        if [ -z "$uname" ];then
                echo "Username of database user:"
        else
                break
        fi
done
echo "Password:"
while read passwd;do
        if [ -z "$passwd" ];then
                #echo "Password:"
				password=''
				break
        else
                break
        fi
done
echo "Save(s)/Re-enter(r):"
while read save;do
        if [ -z "$save" ] ;then
                echo "Save(s)/Re-enter(r):"
        elif [ "$save" != "s" ] && [ "$save" != "r" ];then
		echo "Save(s)/Re-enter(r):"
	else
                break
        fi
done

if [ "$save" = "s" ];then
#test connection
echo Connecting to database. Please wait...
sudo curl -s -o temp.txt --max-time 5 -d "type=$type" -d "host=$host" -d "port=$port" -d "db=$name" -d "user=$uname" -d "password=$passwd" "http://127.0.0.1:39393/test_db"
status=$?
#echo $status
if [ "$status" = "28" ];then
        echo Connection failed. Please check:
	echo 1. If Host IP is correct
	echo 2. If Database server is running
#	echo false > files/temp.txt
	echo 
	echo Please try again
	echo 
        continue
fi
 op=$(head -n 1 temp.txt)
        if [ "$op" == "false" ];then
             echo Access Denied. Please check:
	     echo 1. If database details are correct
	     echo 2. If Database server is running
	     echo 
	     echo Please try again
	     echo 
	     continue
	fi


 c=$(<db_list.txt grep -c '[^[:space:]]')

if [ $c -eq 0 ];then
	echo '{' > data.json
	echo $name > db_list.txt
	if [ $type = "mysql" ];then
		echo \"$name\":\{\"host\":\"$host\",\"port\":\"$port\",\"user\":\"$uname\",\"password\":\"$passwd\",\"type\":\"mysql\"\} >> data.json
	else
		 echo \"$name\":\{\"host\":\"$host\",\"port\":\"$port\",\"native_client\":\"$client\",\"user\":\"$uname\",\"password\":\"$passwd\",\"type\":\"postgresql\"\} >> data.json
	fi
	echo '}' >> data.json
else

	sudo sed '$d' data.json > temp_db_detail.txt
	sudo cp temp_db_detail.txt data.json
	sudo sed "/\"$name\"/d" data.json > temp_db_detail.txt
	sudo cp temp_db_detail.txt data.json
	
	sudo sed "/^$name$/d" db_list.txt >temp_list.txt
	sudo cp temp_list.txt db_list.txt
	echo $name >> db_list.txt
        if [ $type = "mysql" ];then
		 echo ,\"$name\":\{\"host\":\"$host\",\"port\":\"$port\",\"user\":\"$uname\",\"password\":\"$passwd\",\"type\":\"mysql\"\} >> data.json
        else
                 echo ,\"$name\":\{\"host\":\"$host\",\"port\":\"$port\",\"native_client\":\"$client\",\"user\":\"$uname\",\"password\":\"$passwd\",\"type\":\"postgresql\"\} >> data.json
        fi
	echo '}' >>data.json
fi
        sudo sed "2s/^,//" data.json >temp_db_detail.txt
        sudo cp temp_db_detail.txt data.json

	echo "Database added successfully. Databases added so far:"
	echo "----------------------------------------------------"
	cat db_list.txt
	break
fi

done

}

remove_db(){
echo "Enter name of database"
while read name;do
        if [ -z "$name" ];then
                echo "Enter name of database:"
        else
                break
        fi
done

sudo sed "/\"$name\"/d" data.json > temp_db_detail.txt
sudo cp temp_db_detail.txt data.json
sudo sed "2s/^,//" data.json >temp_db_detail.txt
sudo cp temp_db_detail.txt data.json
sudo sed "/^$name$/d" db_list.txt > temp_list.txt
sudo cp temp_list.txt db_list.txt
echo "Database removed successfully. Databases added so far:"
echo "------------------------------------------------------"
cat db_list.txt

}

#echo "Add/remove database details to ubiq agent"
#echo "-----------------------------------------"
#echo "Enter a to add,r to remove,q to quit:"
#while read action;do 
#	if [ "$action" != "a" ] && [ "$action" != "r" ] && [ "$action" != "q" ];then
#		echo "Enter a to add,r to remove,q to quit"
#	else
#		break
#	fi
#done

setup=$(head -n 1 setup.txt)
if [ $setup = 1 ];then

echo "Add/remove database details to ubiq agent"
echo "-----------------------------------------"
echo "Enter a to add,r to remove,q to quit:"
while read action;do 
	if [ "$action" != "a" ] && [ "$action" != "r" ] && [ "$action" != "q" ];then
		echo "Enter a to add,r to remove,q to quit"
	else
		break
	fi
done
else
action=a
fi

case "$action" in
a)add_db
	;;
r)remove_db
	;;
q)exit 1
	;;
esac


