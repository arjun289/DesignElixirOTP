#!/bin/bash
/home/ubuntu/Projects/staging/ubiq_linux_deb/files/start.sh
