#!/bin/bash
#cd $(dirname $0)
cd "`dirname -- "$0"`"

sudo chmod 777 status.txt
sudo chmod 777 forever.txt
sudo chmod 777 log.txt
sudo chmod 755 node64
sudo chmod 755 node32
sudo chmod 755 "$PWD/node_modules/forever/bin/forever32"
sudo chmod 755 "$PWD/node_modules/forever/bin/forever64"
sudo chmod 755 "$PWD/node_modules/forever/bin/foreverd"
sudo chmod 755 "$PWD/node_modules/forever/bin/monitor"

sudo iptables -D INPUT -p tcp --dport 39393 -j ACCEPT 2>/dev/null
sudo iptables -I INPUT -p tcp --dport 39393 -j ACCEPT


u=`uname -m`
if test "$u" == "x86_64"
	then
		sudo "$PWD/node_modules/forever/bin/forever64" stop file.js &> forever.txt
		sudo "$PWD/node_modules/forever/bin/forever64" start file.js start &> forever.txt
		rc=$?
		if [[ $rc == 0 ]] 
			then
				echo "Ubiq started successfully!"
				echo Ubiq is running > status.txt
			else 
				cat forever.txt
		fi
else
		sudo "$PWD/node_modules/forever/bin/forever32" stop file.js &> forever.txt
		sudo "$PWD/node_modules/forever/bin/forever32" start file.js start &> forever.txt
		rc=$?
		if [[ $rc == 0 ]] 
			then
				echo "Ubiq started successfully!"
        			 echo Ubiq is running > status.txt
			else 
				cat forever.txt
		fi
fi
